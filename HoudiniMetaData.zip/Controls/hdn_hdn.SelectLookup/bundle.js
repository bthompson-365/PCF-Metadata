var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./SelectLookup/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./SelectLookup/index.ts":
/*!*******************************!*\
  !*** ./SelectLookup/index.ts ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nvar __awaiter = this && this.__awaiter || function (thisArg, _arguments, P, generator) {\n  function adopt(value) {\n    return value instanceof P ? value : new P(function (resolve) {\n      resolve(value);\n    });\n  }\n\n  return new (P || (P = Promise))(function (resolve, reject) {\n    function fulfilled(value) {\n      try {\n        step(generator.next(value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n\n    function rejected(value) {\n      try {\n        step(generator[\"throw\"](value));\n      } catch (e) {\n        reject(e);\n      }\n    }\n\n    function step(result) {\n      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);\n    }\n\n    step((generator = generator.apply(thisArg, _arguments || [])).next());\n  });\n};\n\nvar __generator = this && this.__generator || function (thisArg, body) {\n  var _ = {\n    label: 0,\n    sent: function sent() {\n      if (t[0] & 1) throw t[1];\n      return t[1];\n    },\n    trys: [],\n    ops: []\n  },\n      f,\n      y,\n      t,\n      g;\n  return g = {\n    next: verb(0),\n    \"throw\": verb(1),\n    \"return\": verb(2)\n  }, typeof Symbol === \"function\" && (g[Symbol.iterator] = function () {\n    return this;\n  }), g;\n\n  function verb(n) {\n    return function (v) {\n      return step([n, v]);\n    };\n  }\n\n  function step(op) {\n    if (f) throw new TypeError(\"Generator is already executing.\");\n\n    while (_) try {\n      if (f = 1, y && (t = op[0] & 2 ? y[\"return\"] : op[0] ? y[\"throw\"] || ((t = y[\"return\"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;\n      if (y = 0, t) op = [op[0] & 2, t.value];\n\n      switch (op[0]) {\n        case 0:\n        case 1:\n          t = op;\n          break;\n\n        case 4:\n          _.label++;\n          return {\n            value: op[1],\n            done: false\n          };\n\n        case 5:\n          _.label++;\n          y = op[1];\n          op = [0];\n          continue;\n\n        case 7:\n          op = _.ops.pop();\n\n          _.trys.pop();\n\n          continue;\n\n        default:\n          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {\n            _ = 0;\n            continue;\n          }\n\n          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {\n            _.label = op[1];\n            break;\n          }\n\n          if (op[0] === 6 && _.label < t[1]) {\n            _.label = t[1];\n            t = op;\n            break;\n          }\n\n          if (t && _.label < t[2]) {\n            _.label = t[2];\n\n            _.ops.push(op);\n\n            break;\n          }\n\n          if (t[2]) _.ops.pop();\n\n          _.trys.pop();\n\n          continue;\n      }\n\n      op = body.call(thisArg, _);\n    } catch (e) {\n      op = [6, e];\n      y = 0;\n    } finally {\n      f = t = 0;\n    }\n\n    if (op[0] & 5) throw op[1];\n    return {\n      value: op[0] ? op[1] : void 0,\n      done: true\n    };\n  }\n};\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar SelectLookup =\n/** @class */\nfunction () {\n  function SelectLookup() {\n    this.entity = \"\";\n    this.options = [];\n    this.firstRun = true;\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  SelectLookup.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.container = container;\n    this.baseUrl = context.page.getClientUrl();\n    this.context = context;\n    var comboBoxContainer = document.createElement(\"div\");\n    comboBoxContainer.className = \"select-wrapper\";\n    this.comboBoxControl = document.createElement(\"select\");\n    this.comboBoxControl.className = \"hdnComboBox\";\n    this.comboBoxControl.addEventListener(\"change\", this.onChange.bind(this));\n    this.comboBoxControl.addEventListener(\"click\", this.onClick.bind(this));\n    this.comboBoxControl.addEventListener(\"mouseenter\", this.onMouseEnter.bind(this));\n    this.comboBoxControl.addEventListener(\"mouseleave\", this.onMouseLeave.bind(this));\n    comboBoxContainer.appendChild(this.comboBoxControl);\n    container.appendChild(comboBoxContainer);\n    this.isDisabled = this.context.mode.isControlDisabled;\n  };\n\n  SelectLookup.prototype.onChange = function () {\n    this.currentValue = this.comboBoxControl.value;\n    this.notifyOutputChanged();\n  };\n\n  SelectLookup.prototype.onClick = function () {\n    if (this.comboBoxControl.className = \"hdnComboBoxFocused\") {\n      this.comboBoxControl.className = \"hdnComboBoxClicked\";\n    } else {\n      this.comboBoxControl.className = \"hdnComboBoxFocused\";\n    }\n  };\n\n  SelectLookup.prototype.onMouseEnter = function () {\n    this.comboBoxControl.className = \"hdnComboBoxFocused\";\n  };\n\n  SelectLookup.prototype.onMouseLeave = function () {\n    this.comboBoxControl.className = \"hdnComboBox\";\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  SelectLookup.prototype.updateView = function (context) {\n    var entity = context.parameters.Entity.raw || \"\";\n\n    if (entity !== this.entity && entity !== \"\") {\n      if (this.firstRun) {\n        this.currentValue = context.parameters.Attribute.raw || \"\";\n        this.firstRun = false;\n      } else {\n        this.currentValue = \"\";\n      } // time to retrive the actual results from the system.\n\n\n      this.entity = entity;\n      this.populateComboBox(entity);\n    } // Add code to update control view\n\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  SelectLookup.prototype.getOutputs = function () {\n    return {\n      Attribute: this.currentValue\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  SelectLookup.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  SelectLookup.prototype.populateComboBox = function (entity) {\n    return __awaiter(this, void 0, void 0, function () {\n      var selectOption, a, result, options, i, text, option, i, i_1;\n      return __generator(this, function (_a) {\n        switch (_a.label) {\n          case 0:\n            selectOption = document.createElement(\"option\");\n            if (!(entity !== \"\")) return [3\n            /*break*/\n            , 2];\n            return [4\n            /*yield*/\n            , this.getEntities(entity)];\n\n          case 1:\n            a = _a.sent();\n            result = JSON.parse(a);\n            options = []; // format all the options into a usable record\n\n            for (i = 0; i < result.value.length; i++) {\n              if (result.value[i].DisplayName !== null && result.value[i].DisplayName.UserLocalizedLabel !== null) {\n                text = result.value[i].DisplayName.UserLocalizedLabel.Label + \" (\" + result.value[i].LogicalName + \")\";\n                option = {\n                  key: result.value[i].LogicalName,\n                  text: text\n                };\n                options.push(option);\n              }\n            } // sort the items into alphabetical order by text.\n\n\n            options.sort(function (a, b) {\n              return a.text.localeCompare(b.text);\n            }); // populate the select option box.\n            // firstly remove all existing options.\n\n            for (i = this.comboBoxControl.options.length - 1; i >= 0; i--) {\n              this.comboBoxControl.remove(i);\n            } // add a top level empty option in case it's needed\n\n\n            selectOption = document.createElement(\"option\");\n            selectOption.innerHTML = \"\";\n            selectOption.value = \"\";\n            this.comboBoxControl.add(selectOption); // add all the sorted records to the list.\n\n            for (i_1 = 0; i_1 < options.length; i_1++) {\n              selectOption = document.createElement(\"option\");\n              selectOption.innerHTML = options[i_1].text;\n              selectOption.value = options[i_1].key;\n\n              if (this.currentValue !== null && this.currentValue === options[i_1].key) {\n                selectOption.selected = true; //\tvalueWasChanged = false;\n              }\n\n              this.comboBoxControl.add(selectOption);\n            }\n\n            _a.label = 2;\n\n          case 2:\n            this.comboBoxControl.disabled = this.isDisabled;\n            return [2\n            /*return*/\n            ];\n        }\n      });\n    });\n  };\n\n  SelectLookup.prototype.getEntities = function (entity) {\n    return __awaiter(this, void 0, void 0, function () {\n      var req, baseUrl;\n      return __generator(this, function (_a) {\n        req = new XMLHttpRequest();\n        baseUrl = this.baseUrl;\n        return [2\n        /*return*/\n        , new Promise(function (resolve, reject) {\n          req.open(\"GET\", baseUrl + \"/api/data/v9.1/EntityDefinitions(LogicalName='\" + entity + \"')/Attributes?$filter=AttributeType%20eq%20Microsoft.Dynamics.CRM.AttributeTypeCode%27entityname%27%20or%20AttributeType%20eq%20Microsoft.Dynamics.CRM.AttributeTypeCode%27Customer%27%20or%20AttributeType%20eq%20Microsoft.Dynamics.CRM.AttributeTypeCode%27Lookup%27\", true);\n\n          req.onreadystatechange = function () {\n            if (req.readyState !== 4) return;\n\n            if (req.status >= 200 && req.status < 300) {\n              // If successful\n              try {\n                var result = JSON.parse(req.responseText);\n\n                if (parseInt(result.StatusCode) < 0) {\n                  reject({\n                    status: result.StatusCode,\n                    statusText: result.StatusMessage\n                  });\n                }\n\n                resolve(req.responseText);\n              } catch (error) {\n                throw error;\n              }\n            } else {\n              // If failed\n              reject({\n                status: req.status,\n                statusText: req.statusText\n              });\n            }\n          };\n\n          req.setRequestHeader(\"OData-MaxVersion\", \"4.0\");\n          req.setRequestHeader(\"OData-Version\", \"4.0\");\n          req.setRequestHeader(\"Accept\", \"application/json\");\n          req.setRequestHeader(\"Content-Type\", \"application/json; charset=utf-8\");\n          req.send();\n        })];\n      });\n    });\n  };\n\n  return SelectLookup;\n}();\n\nexports.SelectLookup = SelectLookup;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./SelectLookup/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('hdn.SelectLookup', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SelectLookup);
} else {
	var hdn = hdn || {};
	hdn.SelectLookup = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SelectLookup;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}